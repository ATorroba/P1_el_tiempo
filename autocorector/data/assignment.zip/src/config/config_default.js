const CONFIG = {
  server_url: "https://api.openweathermap.org/data/2.5/onecall",
  api_key: "<YOUR_API_KEY>",
  num_items: 4,
  default_lat: 40.416775,
  default_lon: -3.703790,
  use_server: true
}

export default CONFIG;