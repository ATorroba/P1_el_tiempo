const CONFIG = {
  server_url: "https://api.openweathermap.org/data/2.5/onecall",
  api_key: "813560a5cd9fd811b4564db03ee31671",
  num_items: 4,
  default_lat: 40.416775,
  default_lon: -3.703790,
  use_server: true //cambiar a true cuando se use con la API real
}

export default CONFIG;